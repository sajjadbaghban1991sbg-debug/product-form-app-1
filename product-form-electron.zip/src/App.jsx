
import React, { useEffect, useState } from "react";

function ManageList({ type, title }) {
  const [items, setItems] = useState([]);
  const [newVal, setNewVal] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const res = await window.electronAPI.listsGet(type);
    setItems(res || []);
  }

  async function add() {
    if (!newVal) return;
    await window.electronAPI.listsAdd(type, newVal);
    setNewVal("");
    load();
  }

  async function update(id, value) {
    await window.electronAPI.listsUpdate(id, value);
    load();
  }

  async function remove(id) {
    if (!confirm("آیا مطمئن هستید حذف شود؟")) return;
    await window.electronAPI.listsDelete(id);
    load();
  }

  return (
    <div className="app-card">
      <h3 className="small">{title}</h3>
      <div style={{marginTop:8}}>
        {items.map(it => (
          <div className="list-item" key={it.id}>
            <div style={{flex:1, textAlign:"right"}}>{it.value}</div>
            <div style={{display:"flex",gap:8}}>
              <button className="btn ghost" onClick={() => {
                const v = prompt("ویرایش کنید:", it.value);
                if (v) update(it.id, v);
              }}>ویرایش</button>
              <button className="btn ghost" onClick={() => remove(it.id)}>حذف</button>
            </div>
          </div>
        ))}
      </div>
      <div style={{display:"flex", gap:8, marginTop:10}}>
        <input className="input" placeholder="افزودن..." value={newVal} onChange={e=>setNewVal(e.target.value)} />
        <button className="btn" onClick={add}>افزودن</button>
      </div>
    </div>
  );
}

export default function App(){
  const [rows, setRows] = useState([]);
  const [productLists, setProductLists] = useState([]);
  const [trainLists, setTrainLists] = useState([]);
  const [routeLists, setRouteLists] = useState([]);
  const [classLists, setClassLists] = useState([]);
  const [filters, setFilters] = useState({start:"", end:""});

  useEffect(()=>{loadLists(); query();},[]);

  async function loadLists(){
    setProductLists(await window.electronAPI.listsGet('product') || []);
    setTrainLists(await window.electronAPI.listsGet('train') || []);
    setRouteLists(await window.electronAPI.listsGet('route') || []);
    setClassLists(await window.electronAPI.listsGet('class') || []);
  }

  function addRow(){
    setRows(prev => [...prev, {product:"", train:"", route:"", quantity:"", classType:"", date:""}]);
  }

  function setRow(i, field, val){
    setRows(prev => {
      const copy = [...prev];
      copy[i] = {...copy[i], [field]: val};
      return copy;
    });
  }

  async function saveRow(i){
    const r = rows[i];
    if(!r.product || !r.train || !r.date) { alert('محصول، قطار و تاریخ الزامی است'); return; }
    await window.electronAPI.entryAdd(r);
    alert('ذخیره شد');
    setRows(prev => { const c=[...prev]; c.splice(i,1); return c;});
  }

  async function query(){
    const res = await window.electronAPI.entryQuery(filters.start, filters.end);
    setSaved(res || []);
  }

  const [saved, setSaved] = useState([]);

  async function exportXlsx(){
    const ok = await window.electronAPI.exportXlsx(saved);
    if(ok && ok.saved) alert('فایل ذخیره شد: ' + ok.path);
  }

  return (
    <div className="container">
      <div className="header">
        <h1>سیستم ثبت محصولات — نسخه دسکتاپ</h1>
        <div style={{display:'flex', gap:8}}>
          <button className="btn" onClick={addRow}>➕ افزودن ردیف</button>
        </div>
      </div>

      <div className="layout">
        <div>
          <div className="app-card">
            <h3 className="small">فیلتر تاریخ و خروجی</h3>
            <div style={{display:'flex', gap:8, marginTop:8}}>
              <input className="input" type="date" value={filters.start} onChange={e=>setFilters({...filters, start:e.target.value})} />
              <input className="input" type="date" value={filters.end} onChange={e=>setFilters({...filters, end:e.target.value})} />
              <button className="btn" onClick={async ()=>{ const res=await window.electronAPI.entryQuery(filters.start, filters.end); setSaved(res || []); }}>جستجو</button>
              <button className="btn ghost" onClick={exportXlsx}>خروجی اکسل</button>
            </div>
          </div>

          <div style={{marginTop:12}}>
            {rows.map((row, i) => (
              <div key={i} className="app-card" style={{marginBottom:10}}>
                <div className="form-row">
                  <select className="input" value={row.product} onChange={e=>setRow(i,'product',e.target.value)}>
                    <option value="">انتخاب محصول</option>
                    {productLists.map(p => <option key={p.id} value={p.value}>{p.value}</option>)}
                  </select>
                  <select className="input" value={row.train} onChange={e=>setRow(i,'train',e.target.value)}>
                    <option value="">قطار</option>
                    {trainLists.map(p => <option key={p.id} value={p.value}>{p.value}</option>)}
                  </select>
                  <select className="input" value={row.route} onChange={e=>setRow(i,'route',e.target.value)}>
                    <option value="">نوع مسیر</option>
                    {routeLists.map(p => <option key={p.id} value={p.value}>{p.value}</option>)}
                  </select>
                  <input className="input" type="number" placeholder="مقدار" value={row.quantity} onChange={e=>setRow(i,'quantity',e.target.value)} />
                  <select className="input" value={row.classType} onChange={e=>setRow(i,'classType',e.target.value)}>
                    <option value="">کلاس</option>
                    {classLists.map(p => <option key={p.id} value={p.value}>{p.value}</option>)}
                  </select>
                  <input className="input" type="date" value={row.date} onChange={e=>setRow(i,'date',e.target.value)} />
                  <button className="btn" onClick={()=>saveRow(i)}>ذخیره</button>
                </div>
              </div>
            ))}
          </div>

          <div style={{marginTop:12}} className="app-card">
            <h3 className="small">نتایج</h3>
            <table className="table">
              <thead>
                <tr><th>ردیف</th><th>محصول</th><th>قطار</th><th>مسیر</th><th>مقدار</th><th>کلاس</th><th>تاریخ</th></tr>
              </thead>
              <tbody>
                {saved.map((s, idx) => (
                  <tr key={s.id}>
                    <td>{idx+1}</td>
                    <td>{s.product}</td>
                    <td>{s.train}</td>
                    <td>{s.route}</td>
                    <td>{s.quantity}</td>
                    <td>{s.classType}</td>
                    <td>{s.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>

        <div style={{display:'flex', flexDirection:'column', gap:10}}>
          <ManageList type="product" title="محصولات" />
          <ManageList type="train" title="قطارها" />
          <ManageList type="route" title="نوع مسیر" />
          <ManageList type="class" title="کلاس‌ها" />
        </div>
      </div>
    </div>
  );
}
